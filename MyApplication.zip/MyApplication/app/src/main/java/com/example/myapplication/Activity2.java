package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class Activity2 extends AppCompatActivity {
    TextView showdata,guidance;//showdata for printing calculated value and guidance for printing
    //whether he is under,overweight or obese
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);
        showdata =(TextView)findViewById(R.id.textView5);
        guidance =(TextView)findViewById(R.id.textView6);

        Float n=getIntent().getFloatExtra("bmi",0);
        showdata.setText("BMI is "+getIntent().getFloatExtra("bmi",0));
        if(n<18.5)
            guidance.setText("UnderWeight..!!!");
        else if (n>=18.5 && n<=24.9)
            guidance.setText("Healthy..!!!");
        else if (n>=25.0 && n<=29.9)
            guidance.setText("Overweight..!!!");
        else if (n>30.0)
            guidance.setText("Obese..!!!");

    }
}
